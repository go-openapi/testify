+++
categories = ['reference']
title = 'Development'
type = 'chapter'
weight = 5

[[cascade]]
  [cascade.params]
    [[cascade.params.sidebarmenus]]
      identifier = 'blog'
      type = 'page'

    [[cascade.params.sidebarmenus]]
      identifier = 'devshortcuts'
      type = 'menu'

[params]
  hidden = true
  menuPre = "<i class='fa-fw fas fa-code-pull-request'></i> "
+++

This chapter contains information only needed for development and maintaining the theme.

{{%children type="list" description="true" %}}
