+++
categories = ['explanation', 'howto']
description = 'Using and extending page designs'
title = 'Page Designs'
weight = 6
+++
{{< piratify >}}