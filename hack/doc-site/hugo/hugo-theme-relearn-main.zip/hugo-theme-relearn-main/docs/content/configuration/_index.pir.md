+++
categories = ['reference']
title = "Configurrrat'n"
type = 'chapter'
weight = 2

[params]
  menuPre = "<i class='fa-fw fas fa-gears'></i> "
+++
{{< piratify >}}