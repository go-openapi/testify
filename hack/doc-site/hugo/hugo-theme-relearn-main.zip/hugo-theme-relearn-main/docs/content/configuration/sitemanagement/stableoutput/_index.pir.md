+++
categories = ['howto']
description = 'How to make your generated HTML output stable'
options = ['disableAssetsBusting', 'disableGeneratorVersion', 'disableRandomIds', 'minify']
title = 'Stable Output'
weight = 8
+++
{{< piratify >}}