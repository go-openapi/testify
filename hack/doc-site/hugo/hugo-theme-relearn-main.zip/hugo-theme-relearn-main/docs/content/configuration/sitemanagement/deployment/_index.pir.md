+++
categories = ['howto']
description = 'Options for specific deployment needs'
title = 'Deployment Scenarios'
weight = 5
+++
{{< piratify >}}