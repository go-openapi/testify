+++
categories = ['howto']
description = 'Changing the width of the sidebar'
title = 'Width'
weight = 1
+++
{{< piratify >}}