+++
categories = ['explanation', 'howto']
description = 'Learn about the hidden pages feature'
options = ['disableSearchHiddenPages', 'disableSeoHiddenPages', 'disableTagHiddenPages']
title = 'Hidden Pages'
weight = 6
+++
{{< piratify >}}