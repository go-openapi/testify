+++
categories = ['howto']
description = 'Provide your own logo, favicon and menu title'
options = ['linkTitle', 'logo']
title = 'Logo & Title'
weight = 1
+++
{{< piratify >}}