+++
categories = ['howto']
description = 'How to keep older versions of your site'
options = ['disableVersioningWarning', 'version', 'versionIndexURL', 'versions']
title = 'Versioning'
weight = 3
+++
{{< piratify >}}