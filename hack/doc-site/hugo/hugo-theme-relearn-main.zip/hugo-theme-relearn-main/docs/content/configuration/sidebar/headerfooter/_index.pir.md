+++
categories = ['howto']
description = 'Configure the header and footer'
options = ['disableLandingPageButton', 'landingPageName', 'showVisitedLinks']
title = 'Header & Footer'
weight = 2
+++
{{< piratify >}}
