+++
categories = ['explanation']
description = "Information on what's stored on the reader's side"
title = 'GDPR & Cookie Consent'
weight = 5
+++
{{< piratify >}}