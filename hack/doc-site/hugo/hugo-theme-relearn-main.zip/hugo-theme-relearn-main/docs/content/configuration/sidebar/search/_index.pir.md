+++
categories = ['howto']
description = 'Configure search and the search form'
options = ['additionalContentLanguage', 'disableSearch', 'disableSearchIndex', 'disableSearchPage', 'searchIndexURL', 'searchPageURL']
title = 'Search'
weight = 3
+++
{{< piratify >}}