+++
categories = ['howto']
description = 'Configuring titles and breadcrumbs to your needs'
options = ['breadcrumbSeparator', 'disableRootBreadcrumb', 'disableTermBreadcrumbs', 'titleSeparator']
title = 'Titles & Breadcrumbs'
weight = 2
+++
{{< piratify >}}