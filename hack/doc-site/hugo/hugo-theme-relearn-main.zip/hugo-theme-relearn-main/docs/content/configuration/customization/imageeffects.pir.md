+++
categories = ['explanation', 'howto']
description = 'How to extend image effects'
options = ['imageEffects']
title = 'Image Effects'
weight = 4
+++
{{< piratify >}}