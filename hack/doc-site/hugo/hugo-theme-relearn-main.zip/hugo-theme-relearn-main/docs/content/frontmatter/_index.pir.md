+++
singulartitle = 'Front Matter'
title = 'Front Matter'
+++
{{< piratify >}}