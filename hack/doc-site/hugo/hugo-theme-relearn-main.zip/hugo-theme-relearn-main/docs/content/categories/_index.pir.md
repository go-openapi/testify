+++
[params.children]
  type = 'card'
+++
{{< piratify >}}