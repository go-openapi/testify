+++
[params]
  [params.children]
    type = "card"

[[cascade]]
  [cascade.params]
    [cascade.params.children]
      breadcrumb = false
      description = true
+++

This taxonmy page and their term pages are configured differently in comparison to the [default](tags). See [the docs](authoring/taxterm) for what's possible.
