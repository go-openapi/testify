+++
categories = ['howto', 'reference']
description = 'Reference of CommonMark and Markdown extensions'
title = 'Marrrkdown Rules'
weight = 4
+++
{{< piratify >}}