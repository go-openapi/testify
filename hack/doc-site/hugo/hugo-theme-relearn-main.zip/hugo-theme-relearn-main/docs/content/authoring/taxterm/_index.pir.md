+++
categories = ['howto']
description = 'How to adjust taxonomy and term pages'
frontmatter = ['children']
title = 'Taxonomy / Term Pages'
weight = 6
+++
{{< piratify >}}