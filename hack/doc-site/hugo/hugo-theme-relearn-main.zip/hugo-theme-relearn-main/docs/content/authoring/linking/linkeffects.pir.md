+++
categories = ['explanation']
description = 'How to apply effects to your links'
frontmatter = ['linkEffects']
title = 'Link Effects'
weight = 2
+++
{{< piratify >}}