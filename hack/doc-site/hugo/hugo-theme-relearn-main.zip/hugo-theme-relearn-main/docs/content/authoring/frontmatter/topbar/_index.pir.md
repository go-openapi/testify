+++
categories = ['howto']
description = 'Configure the topbar'
frontmatter = ['disableBreadcrumb', 'disableNextPrev', 'disableMarkdownButton', 'disableSourceButton', 'disablePrintButton', 'disableToc', 'editURL']
options = ['disableBreadcrumb', 'disableNextPrev', 'disableMarkdownButton', 'disableSourceButton', 'disablePrintButton', 'disableToc', 'editURL']
outputs = ['html', 'rss', 'print', 'markdown', 'source']
title = 'Topbarrr'
weight = 4
+++
{{< piratify >}}