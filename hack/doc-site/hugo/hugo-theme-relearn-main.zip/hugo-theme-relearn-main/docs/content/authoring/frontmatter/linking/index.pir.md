+++
categories = ['howto']
description = 'What options are available for links and images'
frontmatter = ['urlIgnoreCheck', 'externalLinkTarget', 'image.errorlevel', 'link.errorlevel', 'urlExternalCheck']
options = ['urlIgnoreCheck', 'externalLinkTarget', 'image.errorlevel', 'link.errorlevel', 'urlExternalCheck']
title = 'Linking'
weight = 3
+++
{{< piratify >}}