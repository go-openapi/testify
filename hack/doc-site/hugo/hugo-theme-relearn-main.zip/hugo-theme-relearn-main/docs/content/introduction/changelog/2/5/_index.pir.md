+++
title = 'Version 2.5'
type = 'changelog'
weight = -5

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
