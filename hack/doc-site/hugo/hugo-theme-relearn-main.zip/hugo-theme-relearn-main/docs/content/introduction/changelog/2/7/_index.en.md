+++
title = 'Version 2.7'
type = 'changelog'
weight = -7

[params]
  disableToc = false
  hidden = true
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
