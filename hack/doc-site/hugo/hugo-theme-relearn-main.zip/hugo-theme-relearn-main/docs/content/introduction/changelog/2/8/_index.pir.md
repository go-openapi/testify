+++
title = 'Version 2.8'
type = 'changelog'
weight = -8

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
