+++
title = 'Introduction'
type = 'chapter'
weight = 1

[params]
  menuPre = "<i class='fa-fw fas fa-star'></i> "
+++
{{< piratify >}}