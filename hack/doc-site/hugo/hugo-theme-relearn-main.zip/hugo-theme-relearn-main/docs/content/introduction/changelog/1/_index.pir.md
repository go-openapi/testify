+++
title = 'Version 1'
type = 'changelog'
weight = -1

[params]
  disableToc = false
+++
{{< piratify >}}
