+++
title = "{{ replace .Name "-" " " | title }}"
type = "home"
+++

This is your new home page.
